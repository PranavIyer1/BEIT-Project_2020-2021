<?php
/*define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME', 'hms');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);*/
$con=mysqli_connect("project-db.cap2nmqupe3q.ap-south-1.rds.amazonaws.com","admin","dbadmin123","hms");
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>