Web portal for Hospital Management System.



